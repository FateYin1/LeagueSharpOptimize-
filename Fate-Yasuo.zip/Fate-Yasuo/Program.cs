﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LeagueSharp;
using LeagueSharp.Common;
using SharpDX;

namespace GosuMechanicsYasuo
{
    class Program
    {
        public static Spell Q, Q3;
        public static Spell W = new Spell(SpellSlot.W, 400);
        public static Spell E = new Spell(SpellSlot.E, 475);
        public static Spell R = new Spell(SpellSlot.R, 1200);
        public static Spell Ignite;
        public static Spell Flash;
        public static Menu Config;
        public static Orbwalking.Orbwalker Orbwalker;
        public static List<Skillshot> DetectedSkillShots = new List<Skillshot>();
        public static List<Skillshot> EvadeDetectedSkillshots = new List<Skillshot>();
        public static Menu skillShotMenu;
        public static bool isDashing;
        public static YasWall wall = new YasWall();
        public static Obj_AI_Hero myHero { get { return ObjectManager.Player; } }
        public static float HealthPercent { get { return myHero.Health / myHero.MaxHealth * 100; } }     

        public struct IsSafeResult
        {
            public bool IsSafe;
            public List<Skillshot> SkillshotList;
            public List<Obj_AI_Base> casters;
        }
        internal class YasWall
        {
            public MissileClient pointL;
            public MissileClient pointR;
            public float endtime = 0;
            public YasWall()
            {

            }

            public YasWall(MissileClient L, MissileClient R)
            {
                pointL = L;
                pointR = R;
                endtime = Game.Time + 4;
            }

            public void setR(MissileClient R)
            {
                pointR = R;
                endtime = Game.Time + 4;
            }

            public void setL(MissileClient L)
            {
                pointL = L;
                endtime = Game.Time + 4;
            }

            public bool isValid(int time = 0)
            {
                return pointL != null && pointR != null && endtime - (time / 1000) > Game.Time;
            }
        }
        static void Main(string[] args)
        {
            CustomEvents.Game.OnGameLoad += Game_OnGameLoad;
        }

        private static void Game_OnGameLoad(EventArgs args)
        {
            Q = new Spell(SpellSlot.Q, 475);
            Q3 = new Spell(SpellSlot.Q, 1000);

            Q.SetSkillshot(0.25f, 50f, float.MaxValue, false, SkillshotType.SkillshotLine);
            Q3.SetSkillshot(0.5f, 90f, 1200f, false, SkillshotType.SkillshotLine);
            
            var slot = ObjectManager.Player.GetSpellSlot("summonerdot");
            if (slot != SpellSlot.Unknown)
            {
                Ignite = new Spell(slot, 600, TargetSelector.DamageType.True);
            }

            var Fslot = ObjectManager.Player.GetSpellSlot("SummonerFlash");
            if (Fslot != SpellSlot.Unknown)
            {
                Flash = new Spell(slot, 425);
            }

            if (myHero.ChampionName != "Yasuo")
                return;

   
			Config = new Menu("Fate-GosuMechanicsYasuo", "Fate-GosuMechanicsYasuo", true).SetFontStyle(System.Drawing.FontStyle.Regular, SharpDX.Color.Yellow);
          
            //Orbwalker
            Config.AddSubMenu(new Menu("Orbwalker", "Orbwalker").SetFontStyle(System.Drawing.FontStyle.Regular, SharpDX.Color.Yellow));
            Orbwalker = new Orbwalking.Orbwalker(Config.SubMenu("Orbwalker"));
            //TS
            var TargetSelectorMenu = new Menu("Target Selector", "Target Selector").SetFontStyle(System.Drawing.FontStyle.Regular, SharpDX.Color.Yellow);
            TargetSelector.AddToMenu(TargetSelectorMenu);
            Config.AddSubMenu(TargetSelectorMenu);

            Config.AddSubMenu(new Menu("combo", "combo").SetFontStyle(System.Drawing.FontStyle.Regular, SharpDX.Color.Yellow));
            Config.SubMenu("combo").AddItem(new MenuItem("QC", "Use Q").SetFontStyle(System.Drawing.FontStyle.Regular, SharpDX.Color.Yellow)).SetValue(true);
            Config.SubMenu("combo").AddItem(new MenuItem("EC", "Use E").SetFontStyle(System.Drawing.FontStyle.Regular, SharpDX.Color.Yellow)).SetValue(true);
            Config.SubMenu("combo").AddItem(new MenuItem("E1", "When the enemy range >=").SetFontStyle(System.Drawing.FontStyle.Regular, SharpDX.Color.Yellow)).SetValue(new Slider(375, 475, 1));
            Config.SubMenu("combo").AddItem(new MenuItem("E2", "Use E - dash range when the enemy >=").SetFontStyle(System.Drawing.FontStyle.Regular, SharpDX.Color.Yellow)).SetValue(new Slider(475, 1300, 1));
            Config.SubMenu("combo").AddItem(new MenuItem("E3", "Mode: On = E/OFF in the direction of the target = E in the direction of the mouse").SetFontStyle(System.Drawing.FontStyle.Regular, SharpDX.Color.Yellow)).SetValue(true);
          
            Config.SubMenu("combo").AddItem(new MenuItem("Ignite", "The use of ignition").SetFontStyle(System.Drawing.FontStyle.Regular, SharpDX.Color.Yellow)).SetValue(true);
            Config.SubMenu("combo").AddItem(new MenuItem("comboItems", "Use items").SetFontStyle(System.Drawing.FontStyle.Regular, SharpDX.Color.Yellow)).SetValue(true);
            Config.SubMenu("combo").AddItem(new MenuItem("myHP", "if My HP <=").SetFontStyle(System.Drawing.FontStyle.Regular, SharpDX.Color.Yellow)).SetValue(new Slider(70, 101, 1));
            //SmartR
            Config.SubMenu("combo").AddItem(new MenuItem("R", "Smart use of R").SetFontStyle(System.Drawing.FontStyle.Regular, SharpDX.Color.Yellow)).SetValue(true);
            Config.SubMenu("combo").AddItem(new MenuItem("R1", "When the enemy HP <=").SetFontStyle(System.Drawing.FontStyle.Regular, SharpDX.Color.Yellow)).SetValue(new Slider(50, 101, 1));            
            Config.SubMenu("combo").AddItem(new MenuItem("R2", "Or When the number of enemies can blow fly >=").SetFontStyle(System.Drawing.FontStyle.Regular, SharpDX.Color.Yellow)).SetValue(new Slider(2, 5, 1));
            Config.SubMenu("combo").AddItem(new MenuItem("R3", "Whenever a using ER when in the range").SetFontStyle(System.Drawing.FontStyle.Regular, SharpDX.Color.Yellow)).SetValue(true);           
            //Auto R
            Config.SubMenu("combo").AddItem(new MenuItem("R4", "Use auto R").SetFontStyle(System.Drawing.FontStyle.Regular, SharpDX.Color.Yellow)).SetValue(true);
            Config.SubMenu("combo").AddItem(new MenuItem("R5", "When the number of enemies can blow fly >=").SetFontStyle(System.Drawing.FontStyle.Regular, SharpDX.Color.Yellow)).SetValue(new Slider(3, 5, 1));
            Config.SubMenu("combo").AddItem(new MenuItem("R6", "When the number of enemies in range <=").SetFontStyle(System.Drawing.FontStyle.Regular, SharpDX.Color.Yellow)).SetValue(new Slider(2, 5, 1));
            Config.SubMenu("combo").AddItem(new MenuItem("R7", "When My HP >=").SetFontStyle(System.Drawing.FontStyle.Regular, SharpDX.Color.Yellow)).SetValue(new Slider(50, 101, 1));
            //R whitelist
            Config.AddSubMenu(new Menu("ult", "ult").SetFontStyle(System.Drawing.FontStyle.Regular, SharpDX.Color.Yellow));
            foreach (var hero in HeroManager.Enemies.Where(x => x.IsEnemy))
            {
                Config.SubMenu("ult").AddItem(new MenuItem(hero.ChampionName, "The hero with r： " + hero.ChampionName).SetFontStyle(System.Drawing.FontStyle.Regular, SharpDX.Color.Yellow)).SetValue(true);
            }
            //Harass / AutoQ
            Config.AddSubMenu(new Menu("Harass", "Harass").SetFontStyle(System.Drawing.FontStyle.Regular, SharpDX.Color.Yellow));
            Config.SubMenu("Harass").AddItem(new MenuItem("AutoQHarass", "Automatic harassment").SetFontStyle(System.Drawing.FontStyle.Regular, SharpDX.Color.Yellow)).SetValue(new KeyBind('L', KeyBindType.Toggle, true));
            Config.SubMenu("Harass").AddItem(new MenuItem("HarassQ", "Use Q").SetFontStyle(System.Drawing.FontStyle.Regular, SharpDX.Color.Yellow)).SetValue(true);
            Config.SubMenu("Harass").AddItem(new MenuItem("HarassQ3", "Use blow fly").SetFontStyle(System.Drawing.FontStyle.Regular, SharpDX.Color.Yellow)).SetValue(true);
            Config.SubMenu("Harass").AddItem(new MenuItem("HarassTower", "Under the tower harassment").SetFontStyle(System.Drawing.FontStyle.Regular, SharpDX.Color.Yellow)).SetValue(false);
            //LastHit
            Config.AddSubMenu(new Menu("LastHit", "LastHit").SetFontStyle(System.Drawing.FontStyle.Regular, SharpDX.Color.Yellow));
            Config.SubMenu("LastHit").AddItem(new MenuItem("LastHitQ1", "Use Q").SetFontStyle(System.Drawing.FontStyle.Regular, SharpDX.Color.Yellow)).SetValue(true);
            Config.SubMenu("LastHit").AddItem(new MenuItem("LastHitQ3", "Use blow fly").SetFontStyle(System.Drawing.FontStyle.Regular, SharpDX.Color.Yellow)).SetValue(true);
            Config.SubMenu("LastHit").AddItem(new MenuItem("LastHitE", "Use E").SetFontStyle(System.Drawing.FontStyle.Regular, SharpDX.Color.Yellow)).SetValue(true);
            //LaneClear / JungleClear
            Config.AddSubMenu(new Menu("Clear", "Clear").SetFontStyle(System.Drawing.FontStyle.Regular, SharpDX.Color.Yellow));
            Config.SubMenu("Clear").AddItem(new MenuItem("LaneClearQ1", "Use Q").SetFontStyle(System.Drawing.FontStyle.Regular, SharpDX.Color.Yellow)).SetValue(true);
            Config.SubMenu("Clear").AddItem(new MenuItem("LaneClearQ3", "Use blow fly").SetFontStyle(System.Drawing.FontStyle.Regular, SharpDX.Color.Yellow)).SetValue(true);
            Config.SubMenu("Clear").AddItem(new MenuItem("LaneClearQ3count", "Use fly when batman number >= ").SetFontStyle(System.Drawing.FontStyle.Regular, SharpDX.Color.Yellow)).SetValue(new Slider(2, 5, 1));
            Config.SubMenu("Clear").AddItem(new MenuItem("LaneClearE", "Use E").SetFontStyle(System.Drawing.FontStyle.Regular, SharpDX.Color.Yellow)).SetValue(true);
            Config.SubMenu("Clear").AddItem(new MenuItem("LaneClearItems", "Use items").SetFontStyle(System.Drawing.FontStyle.Regular, SharpDX.Color.Yellow)).SetValue(true);
            //Flee away
            Config.AddSubMenu(new Menu("Escape", "Escape").SetFontStyle(System.Drawing.FontStyle.Regular, SharpDX.Color.Yellow));
            Config.SubMenu("Escape").AddItem(new MenuItem("flee", "Escape keys").SetFontStyle(System.Drawing.FontStyle.Regular, SharpDX.Color.Yellow)).SetValue(new KeyBind('Z', KeyBindType.Press, false));
            Config.SubMenu("Escape").AddItem(new MenuItem("wall", "Over the wall to escape").SetFontStyle(System.Drawing.FontStyle.Regular, SharpDX.Color.Yellow)).SetValue(new KeyBind('V', KeyBindType.Press, false));
            Config.SubMenu("Escape").AddItem(new MenuItem("AutoQ1", "Escape for the use of natural and unrestrained in Q stacked layers").SetFontStyle(System.Drawing.FontStyle.Regular, SharpDX.Color.Yellow)).SetValue(true);
            Config.SubMenu("Escape").AddItem(new MenuItem("AutoQToggle", "Auto Q batman target (normal)").SetFontStyle(System.Drawing.FontStyle.Regular, SharpDX.Color.Yellow)).SetValue(new KeyBind('K', KeyBindType.Toggle, true));

            Config.AddSubMenu(new Menu("aShots", "aShots").SetFontStyle(System.Drawing.FontStyle.Regular, SharpDX.Color.Yellow));
            //SmartW
            Config.SubMenu("aShots").AddItem(new MenuItem("smartW", "Auto W").SetFontStyle(System.Drawing.FontStyle.Regular, SharpDX.Color.Yellow)).SetValue(true);
            Config.SubMenu("aShots").AddItem(new MenuItem("smartWDanger", "If skills dangerous level >=").SetFontStyle(System.Drawing.FontStyle.Regular, SharpDX.Color.Yellow)).SetValue(new Slider(3, 5, 1));
            Config.SubMenu("aShots").AddItem(new MenuItem("smartWDelay", "Humanized wind wall (500 = minimum response time)").SetFontStyle(System.Drawing.FontStyle.Regular, SharpDX.Color.Yellow)).SetValue(new Slider(5000, 5000, 500));
            Config.SubMenu("aShots").AddItem(new MenuItem("smartEDogue", "Use EVade").SetFontStyle(System.Drawing.FontStyle.Regular, SharpDX.Color.Yellow)).SetValue(true);
            Config.SubMenu("aShots").AddItem(new MenuItem("smartEDogueDanger", "If skills danger level >=").SetFontStyle(System.Drawing.FontStyle.Regular, SharpDX.Color.Yellow)).SetValue(new Slider(1, 5, 1));
            Config.SubMenu("aShots").AddItem(new MenuItem("wwDanger", "Only when the dangerous to use").SetFontStyle(System.Drawing.FontStyle.Regular, SharpDX.Color.Yellow)).SetValue(false);
            skillShotMenu = getSkilshotMenu();
            Config.SubMenu("aShots").AddSubMenu(skillShotMenu);

            Config.SubMenu("AutoWard").SetFontStyle(System.Drawing.FontStyle.Regular, SharpDX.Color.Yellow).AddItem(new MenuItem("AutoWard", "Start", true)
                .SetFontStyle(System.Drawing.FontStyle.Regular, SharpDX.Color.Yellow)
                .SetValue(true));
            Config.SubMenu("AutoWard").SetFontStyle(System.Drawing.FontStyle.Regular, SharpDX.Color.Yellow).AddItem(new MenuItem("AutoBuy", "lv9Auto blue", true)
                .SetFontStyle(System.Drawing.FontStyle.Regular, SharpDX.Color.Yellow)
                .SetValue(true));
            Config.SubMenu("AutoWard").SetFontStyle(System.Drawing.FontStyle.Regular, SharpDX.Color.Yellow).AddItem(new MenuItem("AutoPink", "Auto Use red", true)
                .SetFontStyle(System.Drawing.FontStyle.Regular, SharpDX.Color.Yellow)
                .SetValue(true));
            Config.SubMenu("AutoWard").SetFontStyle(System.Drawing.FontStyle.Regular, SharpDX.Color.Yellow).AddItem(new MenuItem("AutoWardCombo", "Combo Auto Ward", true)
                .SetFontStyle(System.Drawing.FontStyle.Regular, SharpDX.Color.Yellow)
                .SetValue(true));
            new AutoWard().Load();
            new Tracker().Load();

            var SkinMenu = Config.AddSubMenu(new Menu("Skin", "Skin").SetFontStyle(System.Drawing.FontStyle.Regular, SharpDX.Color.Yellow));
            {
                SkinMenu.AddItem(new MenuItem("EnableSkin", "Start Skin").SetValue(false).SetFontStyle(System.Drawing.FontStyle.Regular, SharpDX.Color.Yellow));
                SkinMenu.AddItem(new MenuItem("SkinSelect", "choose").SetFontStyle(System.Drawing.FontStyle.Regular, SharpDX.Color.Yellow).SetValue(new StringList(new[] { "经典", "1", "2", "3"})));
            }



            //Misc
            Config.AddSubMenu(new Menu("misc", "misc").SetFontStyle(System.Drawing.FontStyle.Regular, SharpDX.Color.Yellow));
            Config.SubMenu("misc").AddItem(new MenuItem("ETower", "Disable E under the tower").SetFontStyle(System.Drawing.FontStyle.Regular, SharpDX.Color.Yellow)).SetValue(true);
            Config.SubMenu("misc").AddItem(new MenuItem("KS", "Auto Ks").SetFontStyle(System.Drawing.FontStyle.Regular, SharpDX.Color.Yellow)).SetValue(true);
            Config.SubMenu("misc").AddItem(new MenuItem("IntAnt", "Use the blow fly - prevent dash/interrupt spell").SetFontStyle(System.Drawing.FontStyle.Regular, SharpDX.Color.Yellow)).SetValue(true);

            Config.AddToMainMenu();

            SkillshotDetector.OnDetectSkillshot += OnDetectSkillshot;
            SkillshotDetector.OnDeleteMissile += OnDeleteMissile;
            Game.OnUpdate += Game_OnUpdate;
            //Drawing.OnDraw += Drawing_OnDraw;
            Obj_AI_Base.OnPlayAnimation += Obj_AI_Base_OnPlayAnimation;
            Interrupter2.OnInterruptableTarget += Interrupter2_OnInterruptableTarget;
            AntiGapcloser.OnEnemyGapcloser += AntiGapcloser_OnEnemyGapcloser;  
        }      

        private static void AntiGapcloser_OnEnemyGapcloser(ActiveGapcloser gapcloser)
        {
            var target = gapcloser.Sender;

            if (!target.IsValidTarget(Q3.Range))
            {
                return;
            }

            if (Q3.IsReady() && Q3READY() && Config.Item("IntAnt").GetValue<bool>())
            {
                Q3.Cast(target);
            }
        }

        private static void Interrupter2_OnInterruptableTarget(Obj_AI_Hero sender, Interrupter2.InterruptableTargetEventArgs args)
        {
            if (sender != null && Q3.IsReady() && Q3READY() && sender.IsValidTarget(Q3.Range) && Config.Item("IntAnt").GetValue<bool>())
            {
                Q3.Cast(sender);
            }
        }

        private static void Obj_AI_Base_OnPlayAnimation(Obj_AI_Base sender, GameObjectPlayAnimationEventArgs args)
        {
            if (!sender.IsMe || args.Animation != "Spell3")
            {
                return;
            }
            isDashing = true;
            Utility.DelayAction.Add(300, () => { if (myHero.IsDashing()) { isDashing = false; } });

            Utility.DelayAction.Add(450, () => isDashing = false);
        }
        private static void Game_OnUpdate(EventArgs args)
        {
            EvadeDetectedSkillshots.RemoveAll(skillshot => !skillshot.IsActive());




            AutoWard.Enable = Config.GetBool("AutoWard");
            AutoWard.AutoBuy = Config.GetBool("AutoBuy");
            AutoWard.AutoPink = Config.GetBool("AutoPink");
            AutoWard.OnlyCombo = Config.GetBool("AutoWardCombo");
            AutoWard.InComboMode = Orbwalker.ActiveMode == Orbwalking.OrbwalkingMode.Combo;

            if (Config.Item("EnableSkin").GetValue<bool>())
            {
                ObjectManager.Player.SetSkin(ObjectManager.Player.CharData.BaseSkinName, Config.Item("SkinSelect").GetValue<StringList>().SelectedIndex);
            }
            else if (!Config.Item("EnableSkin").GetValue<bool>())
            {
                ObjectManager.Player.SetSkin(ObjectManager.Player.CharData.BaseSkinName, 0);
            }



            foreach (var mis in EvadeDetectedSkillshots)
            {
                if (Config.Item("smartW").GetValue<bool>())
                    useWSmart(mis);

                if (Config.Item("smartEDogue").GetValue<bool>() && !isSafePoint(ObjectManager.Player.Position.To2D(), true).IsSafe)
                    useEtoSafe(mis);
            }
            if (Config.Item("flee").GetValue<KeyBind>().Active)
            {
                Flee();
                AutoQFlee();               
                myHero.IssueOrder(GameObjectOrder.MoveTo, Game.CursorPos);
            }
            if (Config.Item("wall").GetValue<KeyBind>().Active)
            {
                Yasuo.WallJump();
            }
            if (Config.Item("AutoQToggle").GetValue<KeyBind>().Active && Orbwalker.ActiveMode == Orbwalking.OrbwalkingMode.None && !Config.Item("flee").GetValue<KeyBind>().Active)
            {
                AutoQ();
            }
            if (Orbwalker.ActiveMode == Orbwalking.OrbwalkingMode.Combo)
            {
                Combo();
            }
            if (Orbwalker.ActiveMode == Orbwalking.OrbwalkingMode.LaneClear)
            {
                LaneClear();
            }
            if (Orbwalker.ActiveMode == Orbwalking.OrbwalkingMode.LastHit)
            {
                LastHit();
            }
            if (Orbwalker.ActiveMode == Orbwalking.OrbwalkingMode.Mixed)
            {
                Harass();
                HarassLastHit();
            }

            AutoR();
            KillSteal();

            if (Config.Item("AutoQHarass").GetValue<KeyBind>().Active && Orbwalker.ActiveMode != Orbwalking.OrbwalkingMode.Combo)
            {
                var TsTarget = TargetSelector.GetTarget(1000, TargetSelector.DamageType.Physical);
                
                if (TsTarget == null || myHero.IsRecalling())
                {
                    return;
                }
                if (TsTarget != null && Config.Item("HarassTower").GetValue<bool>())
                {

                    if (Q3.IsReady() && Config.Item("HarassQ3").GetValue<bool>() && !IsDashing && Q3READY() && Q3.IsInRange(TsTarget))
                    {
                        CastQ3(TsTarget);
                    }
                    else if (!Q3READY() && Q.IsReady() && Config.Item("HarassQ").GetValue<bool>() && !IsDashing && Q.IsInRange(TsTarget))
                    {
                        CastQ12(TsTarget);
                    }
                }
                else if (TsTarget != null || TsTarget != null && !Config.Item("HarassTower").GetValue<bool>())
                {
                    if (!UnderTower(myHero.ServerPosition.To2D()) && Q3.IsReady() && Config.Item("HarassQ3").GetValue<bool>() && !IsDashing && Q3READY() && Q3.IsInRange(TsTarget))
                    {
                        CastQ3(TsTarget);
                    }
                    else if (!Q3READY() && Q.IsReady() && Config.Item("HarassQ").GetValue<bool>() && !IsDashing && !UnderTower(myHero.ServerPosition.To2D()) && Q.IsInRange(TsTarget))
                    {
                        CastQ12(TsTarget);
                    }
                }
            }
        }
        public static void HarassLastHit()
        {
            foreach (Obj_AI_Base minion in MinionManager.GetMinions(myHero.ServerPosition, Q.Range, MinionTypes.All, MinionTeam.Enemy).OrderByDescending(m => m.Health))
            {
                if (minion == null)
                {
                    return;
                }

                if (!minion.IsDead && minion != null && Config.Item("LastHitQ1").GetValue<bool>() && Q.IsReady() && minion.IsValidTarget(500) && !Q3READY() && Q.IsInRange(minion))
                {
                    var predHealth = HealthPrediction.GetHealthPrediction(minion, (int)(Program.myHero.Distance(minion.Position) * 1000 / 2000));
                    if (predHealth <= GetQDmg(minion))
                    {
                        CastQ12(minion);
                    }
                }
            }
        }
        public static void Harass()
        {
            var TsTarget = TargetSelector.GetTarget(1300, TargetSelector.DamageType.Physical);

            if (TsTarget == null)
            {
                return;
            }
            if (TsTarget != null && Config.Item("HarassTower").GetValue<bool>())
            {

                if (Q3.IsReady() && Config.Item("HarassQ3").GetValue<bool>() && !IsDashing && Q3READY() && Q3.IsInRange(TsTarget))
                {
                    CastQ3(TsTarget);
                }
                else if (!Q3READY() && Q.IsReady() && Config.Item("HarassQ").GetValue<bool>() && !IsDashing && Q.IsInRange(TsTarget))
                {
                    CastQ12(TsTarget);
                }
            }
            else if (TsTarget != null && !Config.Item("HarassTower").GetValue<bool>())
            {
                if (!UnderTower(myHero.ServerPosition.To2D()) && Q3.IsReady() && Config.Item("HarassQ3").GetValue<bool>() && !IsDashing && Q3READY() && Q3.IsInRange(TsTarget))
                {
                    CastQ3(TsTarget);
                }
                if (!Q3READY() && Q.IsReady() && Config.Item("HarassQ").GetValue<bool>() && !IsDashing && !UnderTower(myHero.ServerPosition.To2D()) && Q.IsInRange(TsTarget))
                {
                    CastQ12(TsTarget);
                }
            }
        }
        public static void Flee()
        {
            var minions = MinionManager.GetMinions(ObjectManager.Player.ServerPosition, E.Range);
            if (E.IsReady())
            {
                var bestMinion =
                   ObjectManager.Get<Obj_AI_Base>()
                       .Where(x => x.IsValidTarget(E.Range))
                       .Where(x => x.Distance(Game.CursorPos) < ObjectManager.Player.Distance(Game.CursorPos))
                       .OrderByDescending(x => x.Distance(ObjectManager.Player))
                       .FirstOrDefault();

                if (bestMinion != null && ObjectManager.Player.IsFacing(bestMinion) && CanCastE(bestMinion) && E.IsReady())
                {
                    E.CastOnUnit(bestMinion, true);
                }
            }
            foreach (Obj_AI_Hero enemy in ObjectManager.Get<Obj_AI_Hero>().Where(enem => enem.IsEnemy))
            {
                var bestMinion =
                   ObjectManager.Get<Obj_AI_Hero>()
                       .Where(x => x.IsValidTarget(E.Range))
                       .Where(x => x.Distance(Game.CursorPos) < ObjectManager.Player.Distance(Game.CursorPos))
                       .OrderByDescending(x => x.Distance(ObjectManager.Player))
                       .FirstOrDefault();

                if (bestMinion != null && E.IsReady() && ObjectManager.Player.IsFacing(bestMinion))
                {
                    E.CastOnUnit(bestMinion, true);
                }
            }
        }
        public static void AutoQFlee()
        {
            List<Obj_AI_Base> Qminion = MinionManager.GetMinions(ObjectManager.Player.ServerPosition, 1000, MinionTypes.All, MinionTeam.NotAlly);
            foreach (var minion in Qminion.Where(minion => minion.IsValidTarget(Q.Range) && !minion.IsDead))
            {
                if (minion == null)
                {
                    return;
                }
                if (!Q3READY() && Config.Item("AutoQ1").GetValue<bool>() && minion.IsValidTarget(Q.Range) && IsDashing)
                {
                    CastQ12(minion);
                }
            }
        }
        public static void AutoQ()
        {
            List<Obj_AI_Base> Qminion = MinionManager.GetMinions(ObjectManager.Player.ServerPosition, 1000, MinionTypes.All, MinionTeam.NotAlly);
            foreach (var minion in Qminion.Where(minion => minion.IsValidTarget(Q.Range) && !minion.IsDead))
            {
                if (minion == null)
                {
                    return;
                }
                if (!Q3READY() && Config.Item("AutoQ1").GetValue<bool>() && minion.IsValidTarget(Q.Range) && !IsDashing)
                {
                    CastQ12(minion);
                }
            }
        }
        public static void LastHit()
        {
            foreach (Obj_AI_Base minion in MinionManager.GetMinions(myHero.ServerPosition, Q3.Range, MinionTypes.All, MinionTeam.Enemy).OrderByDescending(m => m.Health))
            {
                if (minion == null)
                {
                    return;
                }

                if (!minion.IsDead && minion != null && Config.Item("LastHitQ1").GetValue<bool>() && Q.IsReady() && minion.IsValidTarget(500) && !Q3READY() && Q.IsInRange(minion) && !IsDashing)
                {
                    var predHealth = HealthPrediction.GetHealthPrediction(minion, (int)(Program.myHero.Distance(minion.Position) * 1000 / 2000));
                    if (predHealth <= GetQDmg(minion))
                    {
                        CastQ12(minion);
                    }
                }
                if (!minion.IsDead && minion != null && Config.Item("LastHitQ3").GetValue<bool>() && Q.IsReady() && minion.IsValidTarget(1100) && Q3READY() && Q3.IsInRange(minion) && !IsDashing)
                {
                    var predHealth = HealthPrediction.GetHealthPrediction(minion, (int)(Program.myHero.Distance(minion.Position) * 1000 / 2000));
                    if (predHealth <= GetQDmg(minion))
                    {
                        CastQ3(minion);
                    }
                }
                if (Config.Item("LastHitE").GetValue<bool>() && E.IsReady() && minion.IsValidTarget(475))
                {
                    if (!UnderTower(PosAfterE(minion)) && CanCastE(minion))
                    {
                        var predHealth = HealthPrediction.GetHealthPrediction(minion, (int)(Program.myHero.Distance(minion.Position) * 1000 / 2000));
                        if (predHealth <= GetEDmg(minion))
                        {
                            E.CastOnUnit(minion, true);
                        }
                    }
                }
            }
        }
        public static void LaneClear()
        {
            List<Obj_AI_Base> Qminion = MinionManager.GetMinions(ObjectManager.Player.ServerPosition, 1000, MinionTypes.All, MinionTeam.NotAlly);
            foreach (var minion in Qminion.Where(minion => minion.IsValidTarget(Q3.Range)))
            {
                if (minion == null)
                {
                    return;
                }
                if (minion != null && Config.Item("LaneClearQ1").GetValue<bool>() && Q.IsReady() && minion.IsValidTarget(500) && !Q3READY() && Q.IsInRange(minion))
                {
                    var predHealth = HealthPrediction.LaneClearHealthPrediction(minion, (int)(Program.myHero.Distance(minion.Position) * 1000 / 2000));
                    if (predHealth <= GetQDmg(minion))
                    {
                        CastQ12(minion);
                    }
                    else if (!Q3READY() && Q.IsInRange(minion))
                    {
                        List<Vector2> minionPs = GetCastMinionsPredictedPositions(Qminion, .025f, 50f, float.MaxValue, myHero.ServerPosition, 475f, false, SkillshotType.SkillshotLine);
                        MinionManager.FarmLocation farm = Q.GetLineFarmLocation(minionPs);
                        if (farm.MinionsHit >= 1)
                        {
                            CastQ12(minion);
                        }
                    }
                }
                if (!minion.IsDead && minion != null && Config.Item("LaneClearQ3").GetValue<bool>() && Q3.IsReady() && minion.IsValidTarget(1100) && Q3READY() && Q3.IsInRange(minion))
                {
                    var predHealth = HealthPrediction.LaneClearHealthPrediction(minion, (int)(Program.myHero.Distance(minion.Position) * 1000 / 2000));
                    if (predHealth <= GetQDmg(minion))
                    {
                        CastQ3(minion);
                    }
                    else if (Q3READY() && Q3.IsInRange(minion))
                    {
                        List<Vector2> minionPs = GetCastMinionsPredictedPositions(Qminion, .025f, 50f, float.MaxValue, myHero.ServerPosition, 1000f, false, SkillshotType.SkillshotLine);
                        MinionManager.FarmLocation farm = Q3.GetLineFarmLocation(minionPs);
                        if (farm.MinionsHit >= Config.Item("LaneClearQ3count").GetValue<Slider>().Value)
                        {
                            CastQ3(minion);
                        }
                    }
                }
            }
            var allMinionsE = MinionManager.GetMinions(myHero.ServerPosition, E.Range, MinionTypes.All, MinionTeam.Enemy);
            foreach (var minion in allMinionsE.Where(x => x.IsValidTarget(E.Range) && CanCastE(x)))
            {
                if (minion == null)
                {
                    return;
                }

                if (Config.Item("LaneClearE").GetValue<bool>() && E.IsReady() && minion.IsValidTarget(E.Range) && CanCastE(minion))
                {
                    if (!UnderTower(PosAfterE(minion)))
                    {
                        var predHealth = HealthPrediction.LaneClearHealthPrediction(minion, (int)(Program.myHero.Distance(minion.Position) * 1000 / 2000));
                        if (predHealth <= GetEDmg(minion))
                        {
                            E.CastOnUnit(minion, true);
                        }
                    }
                }
                if (Config.Item("LaneClearItems").GetValue<bool>())
                {
                    UseItems(minion);
                }
            }
            var jminions = MinionManager.GetMinions(myHero.ServerPosition, E.Range, MinionTypes.All, MinionTeam.Neutral);
            foreach (var jungleMobs in jminions.Where(x => x.IsValidTarget(Q3.Range)))
            {
                if (jungleMobs == null)
                {
                    return;
                }
                if (Config.Item("LaneClearE").GetValue<bool>() && E.IsReady() && jungleMobs != null && jungleMobs.IsValidTarget(E.Range) && CanCastE(jungleMobs))
                {
                    E.CastOnUnit(jungleMobs);
                }
                if (jungleMobs != null && Config.Item("LaneClearQ3").GetValue<bool>() && Q3.IsReady() && jungleMobs.IsValidTarget(500) && Q3READY() && Q3.IsInRange(jungleMobs))
                {
                    CastQ3(jungleMobs);
                }
            }
        }
        public static void UseItems(Obj_AI_Base unit)
        {
            if (Items.HasItem((int)ItemId.Blade_of_the_Ruined_King, myHero) && Items.CanUseItem((int)ItemId.Blade_of_the_Ruined_King)
               && Config.Item("comboItems").GetValue<bool>() && HealthPercent <= Config.Item("myHP").GetValue<Slider>().Value)
            {
                Items.UseItem((int)ItemId.Blade_of_the_Ruined_King, unit);
            }
            if (Items.HasItem((int)ItemId.Bilgewater_Cutlass, myHero) && Items.CanUseItem((int)ItemId.Bilgewater_Cutlass)
               && unit.IsValidTarget(Q.Range))
            {
                Items.UseItem((int)ItemId.Bilgewater_Cutlass, unit);
            }
            if (Items.HasItem((int)ItemId.Youmuus_Ghostblade, myHero) && Items.CanUseItem((int)ItemId.Youmuus_Ghostblade)
               && myHero.Distance(unit.Position) <= Q.Range)
            {
                Items.UseItem((int)ItemId.Youmuus_Ghostblade);
            }
            if (Items.HasItem((int)ItemId.Ravenous_Hydra_Melee_Only, myHero) && Items.CanUseItem((int)ItemId.Ravenous_Hydra_Melee_Only)
               && myHero.Distance(unit.Position) <= 400)
            {
                Items.UseItem((int)ItemId.Ravenous_Hydra_Melee_Only);
            }
            if (Items.HasItem((int)ItemId.Tiamat_Melee_Only, myHero) && Items.CanUseItem((int)ItemId.Tiamat_Melee_Only)
               && myHero.Distance(unit.Position) <= 400)
            {
                Items.UseItem((int)ItemId.Tiamat_Melee_Only);
            }
            if (Items.HasItem((int)ItemId.Randuins_Omen, myHero) && Items.CanUseItem((int)ItemId.Randuins_Omen)
               && myHero.Distance(unit.Position) <= 400)
            {
                Items.UseItem((int)ItemId.Randuins_Omen);
            }
        }
        public static void AutoR()
        {
            if (!Program.R.IsReady())
            {
                return;
            }

            var useR = Config.Item("R4").GetValue<bool>();
            var autoREnemies = Config.Item("R5").GetValue<Slider>().Value;
            var MyHP = Config.Item("R7").GetValue<Slider>().Value;
            var enemyInRange = Config.Item("R6").GetValue<Slider>().Value;
            //var useRDown = SubMenu["Combo"]["AutoR3"].Cast<Slider>().CurrentValue;

            if (!useR)
            {
                return;
            }

            var enemiesKnockedUp =
                ObjectManager.Get<Obj_AI_Hero>()
                    .Where(x => x.IsValidTarget(Program.R.Range))
                    .Where(x => x.HasBuffOfType(BuffType.Knockup));

            var enemies = enemiesKnockedUp as IList<Obj_AI_Hero> ?? enemiesKnockedUp.ToList();

            if (enemies.Count() >= autoREnemies && Program.myHero.Health >= MyHP && Program.myHero.CountEnemiesInRange(1500) <= enemyInRange)
            {
                Program.R.Cast();
            }
        }
        public static void Combo()
        {
            var TsTarget = TargetSelector.GetTarget(1300, TargetSelector.DamageType.Physical);
            Orbwalker.ForceTarget(TsTarget);

            if (TsTarget == null)
            {
                return;
            }
            if (TsTarget != null && Config.Item("QC").GetValue<bool>())
            {
                if (Q3READY() && Q3.IsReady() && TsTarget.IsValidTarget(Q3.Range) && !IsDashing)
                {
                    PredictionOutput Q3Pred = Q3.GetPrediction(TsTarget);
                    if (Q3.IsInRange(TsTarget) && Q3Pred.Hitchance >= HitChance.High)
                    {
                        Q3.Cast(Q3Pred.CastPosition, true);
                    }
                }
                if (!Q3READY() && Q.IsReady() && TsTarget.IsValidTarget(Q.Range) && !IsDashing)
                {
                    PredictionOutput QPred = Q.GetPrediction(TsTarget);
                    if (Q.IsInRange(TsTarget) && QPred.Hitchance >= HitChance.High)
                    {
                        Q.Cast(QPred.CastPosition, true);
                        
                    }
                }
            }
            if (E.IsReady() && Config.Item("EC").GetValue<bool>() && TsTarget != null)
            {
                if (TsTarget.Distance(myHero) >= (Config.Item("E1").GetValue<Slider>().Value) && CanCastE(TsTarget) && myHero.IsFacing(TsTarget))
                {
                    E.CastOnUnit(TsTarget, true);
                }
                else if (Q.IsReady() && IsDashing && myHero.Distance(TsTarget) <= 275 * 275)
                {
                    Utility.DelayAction.Add(150, () => { CastQ12(TsTarget); } );
                }
                else if (Q3.IsReady() && myHero.Distance(TsTarget) <= E.Range && Q3READY() && TsTarget != null && E.IsReady())
                {
                    E.CastOnUnit(TsTarget, true);
                }
                else if (Q3.IsReady() && IsDashing && myHero.Distance(TsTarget) <= 275 * 275 && Q3READY())
                {
                    Utility.DelayAction.Add(100, () => { CastQ3(TsTarget); });
                }

                if (Config.Item("E3").GetValue<bool>() && E.IsReady())
                {
                    var bestMinion =
                    ObjectManager.Get<Obj_AI_Minion>()
                    .Where(x => x.IsValidTarget(E.Range))
                    .Where(x => x.Distance(TsTarget) < myHero.Distance(TsTarget))
                    .OrderByDescending(x => x.Distance(myHero))
                    .FirstOrDefault();

                    if (bestMinion != null && TsTarget != null && myHero.IsFacing(bestMinion) && TsTarget.Distance(myHero) >= (Config.Item("E2").GetValue<Slider>().Value) && CanCastE(bestMinion) && myHero.IsFacing(bestMinion))
                    {
                        E.CastOnUnit(bestMinion, true);
                    }
                }
                if (!Config.Item("E3").GetValue<bool>() && E.IsReady())
                {
                       var bestMinion =
                       ObjectManager.Get<Obj_AI_Base>()
                      .Where(x => x.IsValidTarget(E.Range))
                      .Where(x => x.Distance(Game.CursorPos) < ObjectManager.Player.Distance(Game.CursorPos))
                      .OrderByDescending(x => x.Distance(myHero))
                      .FirstOrDefault();

                    if (bestMinion != null && TsTarget != null && myHero.IsFacing(bestMinion) && TsTarget.Distance(myHero) >= (Config.Item("E2").GetValue<Slider>().Value) && CanCastE(bestMinion))
                    {
                        E.CastOnUnit(bestMinion, true);
                    }
                }
            }
            if (Config.Item("flash").GetValue<bool>() && E.IsReady() && R.IsReady() && Flash.IsReady())
            {
                if (TsTarget == null)
                {
                    return;
                }
                var flashQ3range = ((Flash.Range + E.Range) - 25);
                if (Flash != null && TsTarget != null && myHero.Distance(TsTarget) <= flashQ3range && TsTarget.CountEnemiesInRange(400) >= Config.Item("flash2").GetValue<Slider>().Value 
                    && myHero.CountAlliesInRange(1000) >= Config.Item("flash3").GetValue<Slider>().Value)
                {
                    myHero.Spellbook.CastSpell(Flash.Slot, TsTarget.ServerPosition);
                    Utility.DelayAction.Add(10, () => { E.CastOnUnit(TsTarget, true); });
                    Utility.DelayAction.Add(200, () => { CastQ3(TsTarget); });
                }
            }

            if (Program.R.IsReady() && Program.Config.Item("R").GetValue<bool>())
            {
                List<Obj_AI_Hero> enemies = HeroManager.Enemies;
                foreach (Obj_AI_Hero enemy in enemies)
                {
                    if (ObjectManager.Player.Distance(enemy) <= 1200)
                    {
                        var enemiesKnockedUp =
                            ObjectManager.Get<Obj_AI_Hero>()
                            .Where(x => x.IsValidTarget(Program.R.Range))
                            .Where(x => x.HasBuffOfType(BuffType.Knockup));

                        var enemiesKnocked = enemiesKnockedUp as IList<Obj_AI_Hero> ?? enemiesKnockedUp.ToList();
                        if (enemy.IsValidTarget(Program.R.Range) && Program.CanCastDelayR(enemy) && enemiesKnocked.Count() >= (Program.Config.Item("R2").GetValue<Slider>().Value))
                        {
                            Program.R.Cast();
                        }
                    }
                    if (enemy.IsValidTarget(Program.R.Range))
                    {
                        if (Program.IsKnockedUp(enemy) && Program.CanCastDelayR(enemy) && (enemy.Health / enemy.MaxHealth * 100) <= (Program.Config.Item("R1").GetValue<Slider>().Value) && Config.Item(TsTarget.ChampionName).GetValue<bool>())
                        {
                            Program.R.Cast();
                        }
                        else if (Program.IsKnockedUp(enemy) && Program.CanCastDelayR(enemy) && (enemy.Health / enemy.MaxHealth * 100) >= (Program.Config.Item("R1").GetValue<Slider>().Value) && (Program.Config.Item("R3").GetValue<bool>()))
                        {
                            if (Program.AlliesNearTarget(TsTarget, 600))
                            {
                                R.Cast();
                            }
                        }
                    }
                }
                if (Program.Config.Item("Ignite").GetValue<bool>() && TsTarget.Health <= myHero.GetSummonerSpellDamage(TsTarget, Damage.SummonerSpell.Ignite))
                {
                    Ignite.Cast(TsTarget);
                }
                
                if (Program.Config.Item("comboItems").GetValue<bool>() && TsTarget != null && TsTarget.IsValidTarget())
                {
                    UseItems(TsTarget);
                }
            }
        }
        public static void KillSteal()
        {
            foreach (Obj_AI_Hero enemy in HeroManager.Enemies)
            {
                if (enemy.IsValidTarget(Q.Range) && Config.Item("KS").GetValue<bool>())
                {
                    if (Q.IsReady())
                    {
                        
                        if (enemy.Health <= GetQDmg(enemy))
                        {
                            Q.Cast(enemy.ServerPosition, true);
                        }
                    }
                    if (!Q.IsReady() && E.IsReady() && CanCastE(enemy))
                    {
                        
                        if (enemy.Health <= GetEDmg(enemy))
                        {
                            E.CastOnUnit(enemy, true);
                        }
                    }
                    if (Ignite != null && Ignite.IsReady())
                    {
                        
                        if (enemy.Health <= myHero.GetSummonerSpellDamage(enemy, Damage.SummonerSpell.Ignite))
                        {
                            Program.Ignite.Cast(enemy);
                        }
                    }
                }
            }
        }
        public static void CastQ12(Obj_AI_Base target)
        {
            if (target == null)
            {
                return;
            }
            PredictionOutput QPred = Q.GetPrediction(target, true);
            if (QPred.Hitchance >= HitChance.High && Q.IsInRange(target))
            {
                Q.Cast(QPred.CastPosition, true);
            }
        }
        public static void CastQ3(Obj_AI_Base target)
        {
            if (target == null)
            {
                return;
            }
            PredictionOutput Q3Pred = Q3.GetPrediction(target, true);
            if (Q3Pred.Hitchance >= HitChance.VeryHigh && Q3.IsInRange(target))
            {
                Q.Cast(Q3Pred.CastPosition, true);
            }
        }
        public static bool IsKnockedUp(Obj_AI_Hero target)
        {
            return target.HasBuffOfType(BuffType.Knockup) || target.HasBuffOfType(BuffType.Knockback);
        }

        public static bool AlliesNearTarget(Obj_AI_Base target, float range)
        {
            return HeroManager.Allies.Where(tar => tar.Distance(target) < range).Any(tar => tar != null);
        }

        private static bool CanCastDelayR(Obj_AI_Hero target)
        {
            var buff = target.Buffs.FirstOrDefault(i => i.Type == BuffType.Knockback || i.Type == BuffType.Knockup);
            return buff != null && buff.EndTime - Game.Time <= (buff.EndTime - buff.StartTime) / 3;
        }
        public static Vector2 PosAfterE(Obj_AI_Base target)
        {
            return
                myHero.ServerPosition.Extend(
                    target.ServerPosition,
                    myHero.Distance(target) < 410 ? E.Range : myHero.Distance(target) + 65).To2D();
        }
        public static bool UnderTower(Vector2 pos)
        {
            return ObjectManager.Get<Obj_AI_Turret>().Any(i => i.Health > 0 && i.Distance(pos) <= 950 && i.IsEnemy);
        }
        public static bool IsDashing
        {
            get
            {
                return isDashing || myHero.IsDashing();
            }
        }
        public static bool Q3READY()
        {
            return ObjectManager.Player.HasBuff("YasuoQ3W");
        }

        public static bool CanCastE(Obj_AI_Base target)
        {
            return !target.HasBuff("YasuoDashWrapper");
        }
        public static double GetEDmg(Obj_AI_Base target)
        {
            var stacksPassive = myHero.Buffs.Find(b => b.DisplayName.Equals("YasuoDashScalar"));
            var stacks = 1 + 0.25 * ((stacksPassive != null) ? stacksPassive.Count : 0);
            var damage = ((50 + 20 * E.Level) * stacks) + (myHero.FlatMagicDamageMod * 0.6);
            return myHero.CalcDamage(target, Damage.DamageType.Magical, damage);
        }
        public static Vector2 getNextPos(Obj_AI_Hero target)
        {
            Vector2 dashPos = target.Position.To2D();
            if (target.IsMoving && target.Path.Count() != 0)
            {
                Vector2 tpos = target.Position.To2D();
                Vector2 path = target.Path[0].To2D() - tpos;
                path.Normalize();
                dashPos = tpos + (path * 100);
            }
            return dashPos;
        }
        public static void putWallBehind(Obj_AI_Hero target)
        {
            if (!W.IsReady() || !E.IsReady() || target.IsMelee())
                return;
            Vector2 dashPos = getNextPos(target);
            PredictionOutput po = Prediction.GetPrediction(target, 0.5f);

            float dist = myHero.Distance(po.UnitPosition);
            if (!target.IsMoving || myHero.Distance(dashPos) <= dist + 40)
                if (dist < 330 && dist > 100 && W.IsReady())
                {
                    W.Cast(po.UnitPosition, true);
                }
        }

        public static void eBehindWall(Obj_AI_Hero target)
        {
            if (!E.IsReady() || !enemyIsJumpable(target) || target.IsMelee())
                return;
            float dist = myHero.Distance(target);
            var pPos = myHero.Position.To2D();
            Vector2 dashPos = target.Position.To2D();
            if (!target.IsMoving || myHero.Distance(dashPos) <= dist)
            {
                foreach (Obj_AI_Base enemy in ObjectManager.Get<Obj_AI_Base>().Where(enemy => enemyIsJumpable(enemy)))
                {
                    Vector2 posAfterE = pPos + (Vector2.Normalize(enemy.Position.To2D() - pPos) * E.Range);
                    if ((target.Distance(posAfterE) < dist
                        || target.Distance(posAfterE) < Orbwalking.GetRealAutoAttackRange(target) + 100)
                        && goesThroughWall(target.Position, posAfterE.To3D()))
                    {
                        if (useENormal(target))
                            return;
                    }
                }
            }
        }


        public static IsSafeResult isSafePoint(Vector2 point, bool igonre = false)
        {
            var result = new IsSafeResult();
            result.SkillshotList = new List<Skillshot>();
            result.casters = new List<Obj_AI_Base>();


            bool safe = Orbwalker.ActiveMode == Orbwalking.OrbwalkingMode.Combo ||
                        point.To3D().GetEnemiesInRange(500).Count > myHero.HealthPercent % 65;
            if (!safe)
            {
                result.IsSafe = false;
                return result;
            }
            foreach (var skillshot in EvadeDetectedSkillshots)
            {
                if (skillshot.IsDanger(point) && skillshot.IsAboutToHit(500, myHero))
                {
                    result.SkillshotList.Add(skillshot);
                    result.casters.Add(skillshot.Unit);
                }
            }

            result.IsSafe = (result.SkillshotList.Count == 0);
            return result;
        }

        public static Obj_AI_Minion GetCandidates(Obj_AI_Hero player, List<Skillshot> skillshots)
        {
            float currentDashSpeed = 700 + player.MoveSpeed;//At least has to be like this
            IEnumerable<Obj_AI_Minion> minions = ObjectManager.Get<Obj_AI_Minion>();
            Obj_AI_Minion candidate = new Obj_AI_Minion();
            double closest = 10000000000000;
            foreach (Obj_AI_Minion minion in minions)
            {
                if (Vector2.Distance(player.Position.To2D(), minion.Position.To2D()) < 475 && minion.IsEnemy && enemyIsJumpable(minion) && closest > Vector3.DistanceSquared(Game.CursorPos, minion.Position))
                {
                    foreach (Skillshot skillshot in skillshots)
                    {
                        //Get intersection point
                        //  Vector2 intersectionPoint = LineIntersectionPoint(startPos, player.Position.To2D(), endPos, V2E(player.Position, minion.Position, 475));
                        //Time when yasuo will be in intersection point
                        //  float arrivingTime = Vector2.Distance(player.Position.To2D(), intersectionPoint) / currentDashSpeed;
                        //Estimated skillshot position
                        //  Vector2 skillshotPosition = V2E(startPos.To3D(), intersectionPoint.To3D(), speed * arrivingTime);
                        if (skillshot.IsDanger(V2E(player.Position, minion.Position, 475)))
                        {
                            candidate = minion;
                            closest = Vector3.DistanceSquared(Game.CursorPos, minion.Position);
                        }
                    }
                }
            }
            return candidate;
        }

        private static Vector2 V2E(Vector3 from, Vector3 direction, float distance)
        {
            return (from + distance * Vector3.Normalize(direction - from)).To2D();
        }
        public static Vector2 LineIntersectionPoint(Vector2 ps1, Vector2 pe1, Vector2 ps2,
                Vector2 pe2)
        {
            // Get A,B,C of first line - points : ps1 to pe1
            float A1 = pe1.Y - ps1.Y;
            float B1 = ps1.X - pe1.X;
            float C1 = A1 * ps1.X + B1 * ps1.Y;

            // Get A,B,C of second line - points : ps2 to pe2
            float A2 = pe2.Y - ps2.Y;
            float B2 = ps2.X - pe2.X;
            float C2 = A2 * ps2.X + B2 * ps2.Y;

            // Get delta and check if the lines are parallel
            float delta = A1 * B2 - A2 * B1;
            if (delta == 0)
                return new Vector2(-1, -1);

            // now return the Vector2 intersection point
            return new Vector2(
                (B2 * C1 - B1 * C2) / delta,
                (A1 * C2 - A2 * C1) / delta
            );
        }
        public static bool willColide(Skillshot ss, Vector2 from, float speed, Vector2 direction, float radius)
        {
            Vector2 ssVel = ss.Direction.Normalized() * ss.SpellData.MissileSpeed;
            Vector2 dashVel = direction * speed;
            Vector2 a = ssVel - dashVel;//true direction + speed
            Vector2 realFrom = from.Extend(direction, ss.SpellData.Delay + speed);
            if (!ss.IsAboutToHit((int)((dashVel.Length() / 475) * 1000) + Game.Ping + 100, ObjectManager.Player))
                return false;
            if (ss.IsAboutToHit(1000, ObjectManager.Player) && interCir(ss.MissilePosition, ss.MissilePosition.Extend(ss.MissilePosition + a, ss.SpellData.Range + 50), from,
                radius))
                return true;
            return false;
        }
        public static bool interCir(Vector2 E, Vector2 L, Vector2 C, float r)
        {
            Vector2 d = L - E;
            Vector2 f = E - C;

            float a = Vector2.Dot(d, d);
            float b = 2 * Vector2.Dot(f, d);
            float c = Vector2.Dot(f, f) - r * r;

            float discriminant = b * b - 4 * a * c;
            if (discriminant < 0)
            {
                // no intersection
            }
            else
            {
                // ray didn't totally miss sphere,
                // so there is a solution to
                // the equation.

                discriminant = (float)Math.Sqrt(discriminant);

                // either solution may be on or off the ray so need to test both
                // t1 is always the smaller value, because BOTH discriminant and
                // a are nonnegative.
                float t1 = (-b - discriminant) / (2 * a);
                float t2 = (-b + discriminant) / (2 * a);

                // 3x HIT cases:
                //          -o->             --|-->  |            |  --|->
                // Impale(t1 hit,t2 hit), Poke(t1 hit,t2>1), ExitWound(t1<0, t2 hit), 

                // 3x MISS cases:
                //       ->  o                     o ->              | -> |
                // FallShort (t1>1,t2>1), Past (t1<0,t2<0), CompletelyInside(t1<0, t2>1)

                if (t1 >= 0 && t1 <= 1)
                {
                    // t1 is the intersection, and it's closer than t2
                    // (since t1 uses -b - discriminant)
                    // Impale, Poke
                    return true;
                }

                // here t1 didn't intersect so we are either started
                // inside the sphere or completely past it
                if (t2 >= 0 && t2 <= 1)
                {
                    // ExitWound
                    return true;
                }

                // no intn: FallShort, Past, CompletelyInside
                return false;
            }
            return false;
        }
        public static bool wontHitOnDash(Skillshot ss, Obj_AI_Base jumpOn, Skillshot skillShot, Vector2 dashDir)
        {
            float currentDashSpeed = 700 + myHero.MoveSpeed;//At least has to be like this
            //Get intersection point
            Vector2 intersectionPoint = LineIntersectionPoint(myHero.Position.To2D(), V2E(myHero.Position, jumpOn.Position, 475), ss.Start, ss.End);
            //Time when yasuo will be in intersection point
            float arrivingTime = Vector2.Distance(myHero.Position.To2D(), intersectionPoint) / currentDashSpeed;
            //Estimated skillshot position
            Vector2 skillshotPosition = ss.GetMissilePosition((int)(arrivingTime * 1000));
            if (Vector2.DistanceSquared(skillshotPosition, intersectionPoint) <
                (ss.SpellData.Radius + myHero.BoundingRadius) && !willColide(skillShot, myHero.Position.To2D(), 700f + myHero.MoveSpeed, dashDir, myHero.BoundingRadius + skillShot.SpellData.Radius))
                return false;
            return true;
        }

        public static void useEtoSafe(Skillshot skillShot)
        {
            if (!E.IsReady() || skillShotMenu.Item("DangerLevel" + skillShot.SpellData.MenuItemName) != null && Config.Item("smartEDogueDanger").GetValue<Slider>().Value < skillShotMenu.Item("DangerLevel" + skillShot.SpellData.MenuItemName).GetValue<Slider>().Value)
                return;
            float closest = float.MaxValue;
            Obj_AI_Base closestTarg = null;
            float currentDashSpeed = 700 + myHero.MoveSpeed;
            foreach (Obj_AI_Base enemy in ObjectManager.Get<Obj_AI_Base>().Where(ob => ob.NetworkId != skillShot.Unit.NetworkId && enemyIsJumpable(ob) && ob.Distance(myHero) < E.Range).OrderBy(ene => ene.Distance(Game.CursorPos, true)))
            {
                var pPos = myHero.Position.To2D();
                Vector2 posAfterE = V2E(myHero.Position, enemy.Position, 475);
                Vector2 dashDir = (posAfterE - myHero.Position.To2D()).Normalized();

                if (isSafePoint(posAfterE).IsSafe && wontHitOnDash(skillShot, enemy, skillShot, dashDir) /*&& skillShot.IsSafePath(new List<Vector2>() { posAfterE }, 0, (int)currentDashSpeed, 0).IsSafe*/)
                {
                    float curDist = Vector2.DistanceSquared(Game.CursorPos.To2D(), posAfterE);
                    if (curDist < closest)
                    {
                        closestTarg = enemy;
                        closest = curDist;
                    }
                }
            }
            if (closestTarg != null && closestTarg.CountEnemiesInRange(600) <= 2)
                useENormal(closestTarg);
        }

        public static void useWSmart(Skillshot skillShot)
        {
            //try douge with E if cant windWall
            var WDelay = Config.Item("smartWDelay").GetValue<Slider>().Value;

            if (!W.IsReady() || skillShot.SpellData.Type == SkillShotType.SkillshotCircle || skillShot.SpellData.Type == SkillShotType.SkillshotRing)
                return;
            if (skillShot.IsAboutToHit(WDelay, myHero))
            {
                var sd = SpellDatabase.GetByMissileName(skillShot.SpellData.MissileSpellName);
                if (sd == null)
                    return;

                //如果用躲避
                if (!EvadeSpellEnabled(sd.MenuItemName))
                    return;

                //如果仅仅是危险的
                if (Config.Item("wwDanger").GetValue<bool>() && !skillShotIsDangerous(sd.MenuItemName) 
                    || skillShotMenu.Item("DangerLevel" + sd.MenuItemName) != null && Config.Item("smartWDanger").GetValue<Slider>().Value < skillShotMenu.Item("DangerLevel" + sd.MenuItemName).GetValue<Slider>().Value)
                    return;

                    Vector3 blockwhere = myHero.ServerPosition + Vector3.Normalize(skillShot.MissilePosition.To3D() - myHero.ServerPosition) * 10; // missle.Position; 
                myHero.Spellbook.CastSpell(SpellSlot.W, skillShot.Start.To3D(), skillShot.Start.To3D());
            }

        }

        public static bool enemyIsJumpable(Obj_AI_Base enemy, List<Obj_AI_Hero> ignore = null)
        {
            if (enemy.IsValid && enemy.IsEnemy && !enemy.IsInvulnerable && !enemy.MagicImmune && !enemy.IsDead && !(enemy is FollowerObject))
            {
                if (ignore != null)
                    foreach (Obj_AI_Hero ign in ignore)
                    {
                        if (ign.NetworkId == enemy.NetworkId)
                            return false;
                    }
                foreach (BuffInstance buff in enemy.Buffs)
                {
                    if (buff.Name == "YasuoDashWrapper")
                        return false;
                }
                return true;
            }
            return false;
        }
        public static void setUpWall()
        {
            if (wall == null)
                return;

        }     

        public static bool useENormal(Obj_AI_Base target)
        {
            if (!E.IsReady() || target.Distance(myHero) > 468)
            {
                return false;
            }
               
            Vector2 posAfter = V2E(myHero.Position, target.Position, 475);
            if (!Config.Item("ETower").GetValue<bool>())
            {
                if (isSafePoint(posAfter).IsSafe)
                {
                    E.Cast(target, true, false);
                }
                return true;
            }
            else
            {
                Vector2 pPos = myHero.ServerPosition.To2D();
                Vector2 posAfterE = pPos + (Vector2.Normalize(target.Position.To2D() - pPos) * E.Range);
                if (!(posAfterE.To3D().UnderTurret(true)))
                {
                    Console.WriteLine("use gap?");
                    if (isSafePoint(posAfter, true).IsSafe)
                    {
                        E.Cast(target, true, false);
                    }
                    return true;
                }
            }
            return false;

        }
        public static bool goesThroughWall(Vector3 vec1, Vector3 vec2)
        {
            if (wall.endtime < Game.Time || wall.pointL == null || wall.pointL == null)
                return false;
            Vector2 inter = LineIntersectionPoint(vec1.To2D(), vec2.To2D(), wall.pointL.Position.To2D(), wall.pointR.Position.To2D());
            float wallW = (300 + 50 * W.Level);
            if (wall.pointL.Position.To2D().Distance(inter) > wallW ||
                wall.pointR.Position.To2D().Distance(inter) > wallW)
                return false;
            var dist = vec1.Distance(vec2);
            if (vec1.To2D().Distance(inter) + vec2.To2D().Distance(inter) - 30 > dist)
                return false;

            return true;
        }
        public static Menu getSkilshotMenu()
        {
            //Create the skillshots submenus.
            var skillShots = new Menu("Enemy Skillshots", "aShotsSkills");

            foreach (var hero in ObjectManager.Get<Obj_AI_Hero>())
            {
                if (hero.Team != ObjectManager.Player.Team)
                {
                    foreach (var spell in SpellDatabase.Spells)
                    {
                        if (spell.ChampionName == hero.ChampionName)
                        {
                            var subMenu = new Menu(spell.MenuItemName, spell.MenuItemName);

                            subMenu.AddItem(
                                new MenuItem("DangerLevel" + spell.MenuItemName, "Danger level").SetValue(
                                    new Slider(spell.DangerValue, 5, 1)));

                            subMenu.AddItem(
                                new MenuItem("IsDangerous" + spell.MenuItemName, "Is Dangerous").SetValue(
                                    spell.IsDangerous));

                            //subMenu.AddItem(new MenuItem("Draw" + spell.MenuItemName, "Draw").SetValue(true));
                            subMenu.AddItem(new MenuItem("Enabled" + spell.MenuItemName, "Enabled").SetValue(true));

                            skillShots.AddSubMenu(subMenu);
                        }
                    }
                }
            }
            return skillShots;
        }

        public static bool skillShotIsDangerous(string Name)
        {
            if (skillShotMenu.Item("IsDangerous" + Name) != null)
            {
                return skillShotMenu.Item("IsDangerous" + Name).GetValue<bool>();
            }
            return true;
        }
        public static bool EvadeSpellEnabled(string Name)
        {
            if (skillShotMenu.Item("Enabled" + Name) != null)
            {
                return skillShotMenu.Item("Enabled" + Name).GetValue<bool>();
            }
            return true;
        }

        public static void updateSkillshots()
        {
            foreach (var ss in EvadeDetectedSkillshots)
            {
                ss.Game_OnGameUpdate();
            }
        }

        private static void OnDeleteMissile(Skillshot skillshot, MissileClient missile)
        {
            if (skillshot.SpellData.SpellName == "VelkozQ")
            {
                var spellData = SpellDatabase.GetByName("VelkozQSplit");
                var direction = skillshot.Direction.Perpendicular();
                if (EvadeDetectedSkillshots.Count(s => s.SpellData.SpellName == "VelkozQSplit") == 0)
                {
                    for (var i = -1; i <= 1; i = i + 2)
                    {
                        var skillshotToAdd = new Skillshot(
                            DetectionType.ProcessSpell, spellData, Environment.TickCount, missile.Position.To2D(),
                            missile.Position.To2D() + i * direction * spellData.Range, skillshot.Unit);
                        EvadeDetectedSkillshots.Add(skillshotToAdd);
                    }
                }
            }
        }
        private static double GetQDmg(Obj_AI_Base target)
        {
            var dmgItem = 0d;
            if (Items.HasItem(3057) && (Items.CanUseItem(3057) || myHero.HasBuff("Sheen")))
            {
                dmgItem = myHero.BaseAttackDamage;
            }
            if (Items.HasItem(3078) && (Items.CanUseItem(3078) || myHero.HasBuff("Sheen")))
            {
                dmgItem = myHero.BaseAttackDamage * 2;
            }
            var damageModifier = 1d;
            var reduction = 0d;
            var result = dmgItem
                         + myHero.TotalAttackDamage * (myHero.Crit >= 0.85f ? (Items.HasItem(3031) ? 1.875 : 1.5) : 1);
            if (Items.HasItem(3153))
            {
                var dmgBotrk = Math.Max(0.08 * target.Health, 10);
                result += target is Obj_AI_Minion ? Math.Min(dmgBotrk, 60) : dmgBotrk;
            }
            var targetHero = target as Obj_AI_Hero;
            if (targetHero != null)
            {
                if (Items.HasItem(3047, targetHero))
                {
                    damageModifier *= 0.9d;
                }
                if (targetHero.ChampionName == "Fizz")
                {
                    reduction += 4 + (targetHero.Level - 1 / 3) * 2;
                }
                var mastery = targetHero.Masteries.FirstOrDefault(i => i.Page == MasteryPage.Defense && i.Id == 68);
                if (mastery != null && mastery.Points >= 1)
                {
                    reduction += 1 * mastery.Points;
                }
            }
            return myHero.CalcDamage(
                target,
                Damage.DamageType.Physical,
                20 * Q.Level + (result - reduction) * damageModifier)
                   + (HaveStatik
                          ? myHero.CalcDamage(
                              target,
                              Damage.DamageType.Magical,
                              100 * (myHero.Crit >= 0.85f ? (Items.HasItem(3031) ? 2.25 : 1.8) : 1))
                          : 0);
        }
        private static bool HaveStatik
        {
            get
            {
                return myHero.GetBuffCount("ItemStatikShankCharge") == 100;
            }
        }
        public static List<Vector2> GetCastMinionsPredictedPositions(List<Obj_AI_Base> minions,
            float delay,
            float width,
            float speed,
            Vector3 from,
            float range,
            bool collision,
            SkillshotType stype,
            Vector3 rangeCheckFrom = new Vector3())
        {
            var result = new List<Vector2>();
            from = from.To2D().IsValid() ? from : ObjectManager.Player.ServerPosition;
            foreach (var minion in minions)
            {
                var pos = Prediction.GetPrediction(new PredictionInput
                {
                    Unit = minion,
                    Delay = delay,
                    Radius = width,
                    Speed = speed,
                    From = from,
                    Range = range,
                    Collision = collision,
                    Type = stype,
                    RangeCheckFrom = rangeCheckFrom
                });

                if (pos.Hitchance >= HitChance.High)
                {
                    result.Add(pos.CastPosition.To2D());
                }
            }

            return result;
        }
        private static void OnDetectSkillshot(Skillshot skillshot)
        {
            var alreadyAdded = false;

            foreach (var item in EvadeDetectedSkillshots)
            {
                if (item.SpellData.SpellName == skillshot.SpellData.SpellName &&
                    (item.Unit.NetworkId == skillshot.Unit.NetworkId &&
                     (skillshot.Direction).AngleBetween(item.Direction) < 5 &&
                     (skillshot.Start.Distance(item.Start) < 100 || skillshot.SpellData.FromObjects.Length == 0)))
                {
                    alreadyAdded = true;
                }
            }

            //Check if the skillshot is from an ally.
            if (skillshot.Unit.Team == ObjectManager.Player.Team)
            {
                return;
            }

            //Check if the skillshot is too far away.
            if (skillshot.Start.Distance(ObjectManager.Player.ServerPosition.To2D()) >
                (skillshot.SpellData.Range + skillshot.SpellData.Radius + 1000) * 1.5)
            {
                return;
            }

            //Add the skillshot to the detected skillshot list.
            if (!alreadyAdded)
            {
                //Multiple skillshots like twisted fate Q.
                if (skillshot.DetectionType == DetectionType.ProcessSpell)
                {
                    if (skillshot.SpellData.MultipleNumber != -1)
                    {
                        var originalDirection = skillshot.Direction;

                        for (var i = -(skillshot.SpellData.MultipleNumber - 1) / 2;
                            i <= (skillshot.SpellData.MultipleNumber - 1) / 2;
                            i++)
                        {
                            var end = skillshot.Start +
                                      skillshot.SpellData.Range *
                                      originalDirection.Rotated(skillshot.SpellData.MultipleAngle * i);
                            var skillshotToAdd = new Skillshot(
                                skillshot.DetectionType, skillshot.SpellData, skillshot.StartTick, skillshot.Start, end,
                                skillshot.Unit);

                            EvadeDetectedSkillshots.Add(skillshotToAdd);
                        }
                        return;
                    }

                    if (skillshot.SpellData.SpellName == "UFSlash")
                    {
                        skillshot.SpellData.MissileSpeed = 1600 + (int)skillshot.Unit.MoveSpeed;
                    }

                    if (skillshot.SpellData.Invert)
                    {
                        var newDirection = -(skillshot.End - skillshot.Start).Normalized();
                        var end = skillshot.Start + newDirection * skillshot.Start.Distance(skillshot.End);
                        var skillshotToAdd = new Skillshot(
                            skillshot.DetectionType, skillshot.SpellData, skillshot.StartTick, skillshot.Start, end,
                            skillshot.Unit);
                        EvadeDetectedSkillshots.Add(skillshotToAdd);
                        return;
                    }

                    if (skillshot.SpellData.Centered)
                    {
                        var start = skillshot.Start - skillshot.Direction * skillshot.SpellData.Range;
                        var end = skillshot.Start + skillshot.Direction * skillshot.SpellData.Range;
                        var skillshotToAdd = new Skillshot(
                            skillshot.DetectionType, skillshot.SpellData, skillshot.StartTick, start, end,
                            skillshot.Unit);
                        EvadeDetectedSkillshots.Add(skillshotToAdd);
                        return;
                    }

                    if (skillshot.SpellData.SpellName == "SyndraE" || skillshot.SpellData.SpellName == "syndrae5")
                    {
                        var angle = 60;
                        var edge1 =
                            (skillshot.End - skillshot.Unit.ServerPosition.To2D()).Rotated(
                                -angle / 2 * (float)Math.PI / 180);
                        var edge2 = edge1.Rotated(angle * (float)Math.PI / 180);

                        foreach (var minion in ObjectManager.Get<Obj_AI_Minion>())
                        {
                            var v = minion.ServerPosition.To2D() - skillshot.Unit.ServerPosition.To2D();
                            if (minion.Name == "Seed" && edge1.CrossProduct(v) > 0 && v.CrossProduct(edge2) > 0 &&
                                minion.Distance(skillshot.Unit) < 800 &&
                                (minion.Team != ObjectManager.Player.Team))
                            {
                                var start = minion.ServerPosition.To2D();
                                var end = skillshot.Unit.ServerPosition.To2D()
                                    .Extend(
                                        minion.ServerPosition.To2D(),
                                        skillshot.Unit.Distance(minion) > 200 ? 1300 : 1000);

                                var skillshotToAdd = new Skillshot(
                                    skillshot.DetectionType, skillshot.SpellData, skillshot.StartTick, start, end,
                                    skillshot.Unit);
                                EvadeDetectedSkillshots.Add(skillshotToAdd);
                            }
                        }
                        return;
                    }

                    if (skillshot.SpellData.SpellName == "AlZaharCalloftheVoid")
                    {
                        var start = skillshot.End - skillshot.Direction.Perpendicular() * 400;
                        var end = skillshot.End + skillshot.Direction.Perpendicular() * 400;
                        var skillshotToAdd = new Skillshot(
                            skillshot.DetectionType, skillshot.SpellData, skillshot.StartTick, start, end,
                            skillshot.Unit);
                        EvadeDetectedSkillshots.Add(skillshotToAdd);
                        return;
                    }

                    if (skillshot.SpellData.SpellName == "ZiggsQ")
                    {
                        var d1 = skillshot.Start.Distance(skillshot.End);
                        var d2 = d1 * 0.4f;
                        var d3 = d2 * 0.69f;


                        var bounce1SpellData = SpellDatabase.GetByName("ZiggsQBounce1");
                        var bounce2SpellData = SpellDatabase.GetByName("ZiggsQBounce2");

                        var bounce1Pos = skillshot.End + skillshot.Direction * d2;
                        var bounce2Pos = bounce1Pos + skillshot.Direction * d3;

                        bounce1SpellData.Delay =
                            (int)(skillshot.SpellData.Delay + d1 * 1000f / skillshot.SpellData.MissileSpeed + 500);
                        bounce2SpellData.Delay =
                            (int)(bounce1SpellData.Delay + d2 * 1000f / bounce1SpellData.MissileSpeed + 500);

                        var bounce1 = new Skillshot(
                            skillshot.DetectionType, bounce1SpellData, skillshot.StartTick, skillshot.End, bounce1Pos,
                            skillshot.Unit);
                        var bounce2 = new Skillshot(
                            skillshot.DetectionType, bounce2SpellData, skillshot.StartTick, bounce1Pos, bounce2Pos,
                            skillshot.Unit);

                        EvadeDetectedSkillshots.Add(bounce1);
                        EvadeDetectedSkillshots.Add(bounce2);
                    }

                    if (skillshot.SpellData.SpellName == "ZiggsR")
                    {
                        skillshot.SpellData.Delay =
                            (int)(1500 + 1500 * skillshot.End.Distance(skillshot.Start) / skillshot.SpellData.Range);
                    }

                    if (skillshot.SpellData.SpellName == "JarvanIVDragonStrike")
                    {
                        var endPos = new Vector2();

                        foreach (var s in EvadeDetectedSkillshots)
                        {
                            if (s.Unit.NetworkId == skillshot.Unit.NetworkId && s.SpellData.Slot == SpellSlot.E)
                            {
                                endPos = s.End;
                            }
                        }

                        foreach (var m in ObjectManager.Get<Obj_AI_Minion>())
                        {
                            if (m.CharData.BaseSkinName == "jarvanivstandard" && m.Team == skillshot.Unit.Team &&
                                skillshot.IsDanger(m.Position.To2D()))
                            {
                                endPos = m.Position.To2D();
                            }
                        }

                        if (!endPos.IsValid())
                        {
                            return;
                        }

                        skillshot.End = endPos + 200 * (endPos - skillshot.Start).Normalized();
                        skillshot.Direction = (skillshot.End - skillshot.Start).Normalized();
                    }
                }

                if (skillshot.SpellData.SpellName == "OriannasQ")
                {
                    var endCSpellData = SpellDatabase.GetByName("OriannaQend");

                    var skillshotToAdd = new Skillshot(
                        skillshot.DetectionType, endCSpellData, skillshot.StartTick, skillshot.Start, skillshot.End,
                        skillshot.Unit);

                    EvadeDetectedSkillshots.Add(skillshotToAdd);
                }


                //Dont allow fow detection.
                if (skillshot.SpellData.DisableFowDetection && skillshot.DetectionType == DetectionType.RecvPacket)
                {
                    return;
                }
#if DEBUG
                    Console.WriteLine(Environment.TickCount + "Adding new skillshot: " + skillshot.SpellData.SpellName);
#endif

                EvadeDetectedSkillshots.Add(skillshot);
            }
        }
       
    }
}